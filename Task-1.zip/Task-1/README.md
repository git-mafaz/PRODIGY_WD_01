# Ecommerce Watches

- Responsive Watches Website ⌚

# Language

1. Html
2. Css
3. Javascript

# Tools

1. Pug
2. Scss

# Plugins

1. Swier [Website](https://swiperjs.com/)

# Website

Link [Show](https://tomorrowwebsite.github.io/Ecommerce-Watches/dist/index.html)

# Previw

![This is an image](https://raw.githubusercontent.com/tomorrowWebsite/Ecommerce-Watches/main/dist/preview.png)

